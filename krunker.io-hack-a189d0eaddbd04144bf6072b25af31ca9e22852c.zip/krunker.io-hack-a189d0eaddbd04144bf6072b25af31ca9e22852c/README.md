# Krunker.io Hack
**This is the only working krunker.io hack. It was made thanks to the collaborators named below and no one else. All the other scripts are a copy from this one (e.g: quake.pw (quake#5338), who copied this hack and claimed it as his hack)**

### Features:
- Aimbot
- FPS Counter
- Tracers
- ESP (aka. Wallhack)
- BHop
- NoRecoil

### Requirements:
- Tampermonkey
- ES6 Support

### Userscript: https://github.com/xF4b3r/krunker/raw/master/userscript.user.js

### Collaborators:
- William Thomson
- Tehchy

### Preview:
![](https://i.imgur.com/bd1gjNS.png?raw=true)
